/** Shown on legal pages until Pork & Go (and their lawyer) approve the final wording. */
export function DraftNote() {
  return (
    <p className="mb-8 rounded-2xl bg-glow/10 px-5 py-4 text-sm text-glow ring-1 ring-glow/30">
      Draft for review. Pork &amp; Go will confirm the final wording before the site goes live.
    </p>
  );
}
